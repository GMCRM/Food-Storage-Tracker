// Initialize items array
// This line looks in localStorage (a built-in browser storage area)
// and retrieves any previously saved items. If none exist, it starts with an empty array.
// Where I learned it:
// - JSON.parse(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON/parse
// - localStorage.getItem(): https://developer.mozilla.org/en-US/docs/Web/API/Storage/getItem
// - Web Storage API overview: https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API/Using_the_Web_Storage_API
let items = JSON.parse(localStorage.getItem("items")) || [];

// Implement "Add Item" function
function addItem(event) {
  // Prevent the default form submission (which refreshes the page)
  // Where I learned it: https://developer.mozilla.org/en-US/docs/Web/API/Event/preventDefault
  event.preventDefault();

  // Capture form inputs using their IDs
  // Where I learned it: https://developer.mozilla.org/en-US/docs/Web/API/Document/getElementById
  const itemName = document.getElementById("item-name").value;
  const itemDescription = document.getElementById("item-description").value;
  const itemStorageType = document.getElementById("item-storage-type").value;
  const dateStored = document.getElementById("dateStored").value;
  const useByDate = document.getElementById("useByDate").value;

  // Calculate days left until expiration
  // Where I learned it: Date: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date
  const today = new Date();
  const useBy = new Date(useByDate);
  const daysLeft = Math.ceil((useBy - today) / (1000 * 60 * 60 * 24));

  // Build an object representing one food item
  // // Where I learned it: objects: https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Objects/Basics
  const newItem = {
    name: itemName,
    description: itemDescription,
    storageType: itemStorageType,
    dateStored: dateStored,
    useByDate: useByDate,
    daysLeft: daysLeft,
  };

  // Add this object to the array of items
  // Where I learned it: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/push
  items.push(newItem);

  // Save the updated array to localStorage (as a JSON string)
  // Where I learned it:
  // - JSON.stringify(): https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON/stringify
  // - localStorage.setItem(): https://developer.mozilla.org/en-US/docs/Web/API/Storage/setItem
  localStorage.setItem("items", JSON.stringify(items));

  // Clear form inputs for the next entry
  // Where I learned it: https://developer.mozilla.org/en-US/docs/Web/API/HTMLFormElement/reset
  document.getElementById("item-form").reset();

  // Re-render the table to show the updated list
  renderTable();
}

// Helper function to format date as MM/DD/YYYY (changed from MM-DD-YYYY)
// function formatDate(dateString) {
//   const date = new Date(dateString);
//   const month = String(date.getMonth() + 1).padStart(2, "0"); // +1 because months are 0-indexed
//   const day = String(date.getDate()).padStart(2, "0");
//   const year = date.getFullYear();
//   return `${month}/${day}/${year}`; // Changed from dashes to slashes
// }

// Helper function to format date as MM/DD/YYYY using moment.js
function formatDate(dateString) {
  return moment(dateString).format("MM/DD/YYYY");
}

// Helper function to capitalize first letter
function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// Render the table — dynamically updates the HTML table with stored items
function renderTable() {
  const tableBody = document.getElementById("item-table-body");
  if (!tableBody) {
    console.error('tbody with id "item-table-body" not found');
    return;
  }

  // Clear the current table content
  tableBody.innerHTML = "";

  // Loop through the items array
  // Where I learned it: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/forEach
  items.forEach((item, index) => {
    const row = document.createElement("tr");

    // Add cells for each property
    const nameCell = document.createElement("td");
    nameCell.textContent = item.name;
    row.appendChild(nameCell);

    const descriptionCell = document.createElement("td");
    descriptionCell.textContent = item.description;
    row.appendChild(descriptionCell);

    const storageCell = document.createElement("td");
    storageCell.textContent = capitalize(item.storageType); // Capitalize storage type
    row.appendChild(storageCell);

    const dateStoredCell = document.createElement("td");
    dateStoredCell.textContent = formatDate(item.dateStored); // Format with slashes
    row.appendChild(dateStoredCell);

    const useByDateCell = document.createElement("td");
    useByDateCell.textContent = formatDate(item.useByDate); // Format with slashes
    row.appendChild(useByDateCell);

    const daysLeftCell = document.createElement("td");
    daysLeftCell.textContent = item.daysLeft;
    row.appendChild(daysLeftCell);

    // Add action buttons (Edit and Delete)
    const actionsCell = document.createElement("td");

    const editButton = document.createElement("button");
    editButton.textContent = "Edit";
    editButton.onclick = () => editItem(index);

    const deleteButton = document.createElement("button");
    deleteButton.textContent = "Delete";
    deleteButton.onclick = () => deleteItem(index);

    actionsCell.appendChild(editButton);
    actionsCell.appendChild(deleteButton);
    row.appendChild(actionsCell);

    tableBody.appendChild(row);
  });

  // Count and log items expiring in the next 7 days
  const expiringCount = countExpiringItems(items, 7);
  console.log(`${expiringCount} items expiring soon!`);
}

// Recursive function to count items expiring within X days
function countExpiringItems(itemsArray, daysThreshold, index = 0, count = 0) {
  // Base case: if we've checked all items
  if (index >= itemsArray.length) {
    return count;
  }

  // Check if current item expires within threshold
  if (
    itemsArray[index].daysLeft <= daysThreshold &&
    itemsArray[index].daysLeft >= 0
  ) {
    count++;
  }

  // Recursive call with next index
  return countExpiringItems(itemsArray, daysThreshold, index + 1, count);
}

// Delete an item
function deleteItem(index) {
  // Remove one element from the array
  // Where I learned it: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/splice
  items.splice(index, 1);

  // Update localStorage
  localStorage.setItem("items", JSON.stringify(items));

  // Re-render the updated table
  renderTable();
}

// Edit an existing item (by loading it back into the form)
function editItem(index) {
  const item = items[index];

  // Pre-fill the form fields with the existing data
  document.getElementById("item-name").value = item.name;
  document.getElementById("item-description").value = item.description;
  document.getElementById("item-storage-type").value = item.storageType;
  document.getElementById("dateStored").value = item.dateStored;
  document.getElementById("useByDate").value = item.useByDate;

  // Remove the old version of the item so it gets replaced on submit
  deleteItem(index);
}

// Attach an event listener so the form calls addItem() when submitted
// Where I learned it: https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener
document.getElementById("item-form").addEventListener("submit", addItem);

// Run once at startup to show existing data
renderTable();

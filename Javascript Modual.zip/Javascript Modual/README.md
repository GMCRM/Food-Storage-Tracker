# Food Storage Tracker

## Overview

The **Food Storage Tracker** is a web application I built to strengthen my JavaScript skills by working with core concepts such as DOM manipulation, event handling, object creation, browser storage, and external libraries.

This project demonstrates how to build an interactive web app that allows users to track their food items — including names, descriptions, storage types, and expiration dates — and automatically calculates how many days remain before each item expires. Users can add, edit, and delete food items with data persisting between browser sessions.

The goal of this project was to gain hands-on experience with JavaScript syntax, browser APIs, and integrating external libraries while building something practical and interactive.

[**Software Demo Video**](https://youtu.be/UI3hvlxfzl4?si=011n6g0tIBsD22qs)

---

## Development Environment

- **Code Editor:** Visual Studio Code  
- **Version Control:** Git & GitHub  
- **Browser:** Google Chrome (for testing and debugging)
- **Languages Used:**  
  - HTML for structure and form elements
  - CSS for styling and responsive layout with CSS Grid/Flexbox
  - JavaScript (ES6) for logic, DOM manipulation, and data handling

**External Libraries:**
- **Moment.js** (via CDN) for date formatting and manipulation

**Browser APIs Used:**
- **Web Storage API (localStorage)** for data persistence
- **DOM API** for dynamic HTML table rendering and form handling

---

## Key Features Implemented

- **Dynamic Form Handling:** Add food items with validation and form reset
- **Data Persistence:** Items stored in localStorage survive browser sessions
- **Interactive Table:** Display all food items with edit/delete functionality
- **Date Calculations:** Automatic countdown of days until expiration
- **Responsive Layout:** CSS Grid and Flexbox for proper form alignment
- **External Library Integration:** Moment.js for clean date formatting
- **ES6 Array Methods:** forEach(), push(), splice() for data manipulation
- **Recursive Functions:** Custom recursive function for counting expiring items

---

## Useful Websites

Below are the most helpful references I used while learning and building the project:

- [MDN Web Docs – Web Storage API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API/Using_the_Web_Storage_API)
- [MDN Web Docs – JSON.parse()](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON/parse)
- [MDN Web Docs – localStorage.getItem()](https://developer.mozilla.org/en-US/docs/Web/API/Storage/getItem)
- [MDN Web Docs – localStorage.setItem()](https://developer.mozilla.org/en-US/docs/Web/API/Storage/setItem)
- [MDN Web Docs – Event.preventDefault()](https://developer.mozilla.org/en-US/docs/Web/API/Event/preventDefault)
- [MDN Web Docs – HTMLFormElement.reset()](https://developer.mozilla.org/en-US/docs/Web/API/HTMLFormElement/reset)
- [MDN Web Docs – EventTarget.addEventListener()](https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener)
- [MDN Web Docs – Array.forEach()](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/forEach)
- [Moment.js Documentation](https://momentjs.com/docs/) - Date formatting library

---

## Future Work

There are several areas where the Food Storage Tracker could be improved or extended in the future:

- Add **search and sorting functionality** to make it easier to find items by name or expiration date
- Implement a **filter system** to view only items stored in the fridge, freezer, or pantry
- Add **visual alerts or color indicators** for items that are close to their expiration date
- Improve **inline editing** so users can modify items directly in the table
- Add **data validation** for form inputs (date ranges, required fields)
- Implement **data export/import** features to back up the food inventory
- Add **charts or statistics** showing storage distribution using Chart.js
- Improve **mobile responsiveness** and overall UI/UX design
- Add **notification system** for items expiring soon